#!/usr/bin/env python3
"""Reproducible bilingual project record. All diagrams are vector artwork."""
from pathlib import Path
import hashlib, json, re, html
from datetime import datetime, timezone
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor, Color, white
from reportlab.lib.styles import ParagraphStyle
from reportlab.platypus import Paragraph
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
W,H=595.276,841.89
M=42; CW=W-2*M
P={'navy':'142C43','ink':'223B4A','muted':'62737B','teal':'137D83','teal_light':'E2F0EE',
   'amber':'AA701F','amber_light':'F7EEDC','rust':'AD5144','rust_light':'F8EAE4',
   'paper':'F7F6F1','line':'D8DFDC','white':'FFFFFF','blue':'E9EFF5','slate':'536B82'}
def col(k):return HexColor('#'+P.get(k,k))
for n,p in [('Sans','/System/Library/Fonts/Supplemental/Arial.ttf'),('Bold','/System/Library/Fonts/Supplemental/Arial Bold.ttf'),
            ('CN','/System/Library/Fonts/STHeiti Light.ttc'),('CNB','/System/Library/Fonts/STHeiti Medium.ttc')]:
    pdfmetrics.registerFont(TTFont(n,p,subfontIndex=0))
pdfmetrics.registerFontFamily('Sans',normal='Sans',bold='Bold',italic='Sans',boldItalic='Bold')
pdfmetrics.registerFontFamily('CN',normal='CN',bold='CNB',italic='CN',boldItalic='CNB')

LANG='en'; C=None; OVERFLOWS=[]
def tx(en,zh):return zh if LANG=='zh' else en
def font(bold=False):return ('CNB' if bold else 'CN') if LANG=='zh' else ('Bold' if bold else 'Sans')
def rect(x,y,w,h,fill='white',stroke=None,r=9):
    C.setFillColor(col(fill));C.setStrokeColor(col(stroke or fill));C.setLineWidth(.7)
    C.roundRect(x,H-y-h,w,h,r,fill=1,stroke=int(bool(stroke)))
def line(x1,y1,x2,y2,color='line',width=1,dash=None):
    C.setStrokeColor(col(color));C.setLineWidth(width);C.setDash(dash or [])
    C.line(x1,H-y1,x2,H-y2);C.setDash([])
def label(text,x,y,size=9,color='muted',bold=False):
    C.setFillColor(col(color));C.setFont(font(bold),size);C.drawString(x,H-y-size*.82,text)
def right(text,x,y,size=9,color='muted',bold=False):
    C.setFillColor(col(color));C.setFont(font(bold),size);C.drawRightString(x,H-y-size*.82,text)
def para(text,x,y,w,size=11.1,color='ink',bold=False,leading=None,maxh=None):
    # Literal text is escaped; explicit <b> markup is retained for emphasis.
    text=html.escape(text).replace('&lt;b&gt;','<b>').replace('&lt;/b&gt;','</b>').replace('\n','<br/>')
    st=ParagraphStyle('p',fontName=font(bold),fontSize=size,leading=leading or size*1.43,
       textColor=col(color),wordWrap='CJK' if LANG=='zh' else None,splitLongWords=True,
       spaceAfter=0,allowWidows=0,allowOrphans=0)
    p=Paragraph(text,st);_,h=p.wrap(w,1000)
    if maxh and h>maxh+.1:OVERFLOWS.append({'page':C.getPageNumber(),'text':text[:80],'height':round(h,1),'allowed':maxh})
    p.drawOn(C,x,H-y-h);return h
def arrow(points,color='teal',width=1.45,dash=None):
    for (x1,y1),(x2,y2) in zip(points,points[1:]):line(x1,y1,x2,y2,color,width,dash)
    (x1,y1),(x2,y2)=points[-2:]
    import math
    a=math.atan2(y2-y1,x2-x1);s=4.6
    path=C.beginPath();path.moveTo(x2,H-y2)
    path.lineTo(x2-s*math.cos(a-.50),H-(y2-s*math.sin(a-.50)))
    path.lineTo(x2-s*math.cos(a+.50),H-(y2-s*math.sin(a+.50)));path.close()
    C.setFillColor(col(color));C.drawPath(path,fill=1,stroke=0)
def dot(x,y,color='teal',r=3):
    C.setFillColor(col(color));C.circle(x,H-y,r,stroke=0,fill=1)
def card(x,y,w,h,num,title,body,color='teal',fill='white',fs=10.3):
    rect(x,y,w,h,fill,'line');rect(x+12,y+13,25,22,color,r=5)
    label(num,x+17,y+19,9,'white',True)
    para(title,x+47,y+14,w-59,12,color,True,maxh=38)
    para(body,x+14,y+48,w-28,fs,maxh=h-59)
def node(x,y,w,h,title,body='',fill='white',accent='teal',fs=10.4):
    rect(x,y,w,h,fill,'line',7);rect(x,y,4,h,accent,r=2)
    para(title,x+12,y+11,w-24,fs,accent,True,maxh=34)
    if body:para(body,x+12,y+34,w-24,9.1,'ink',maxh=h-42)
def pill(text,x,y,w,color='teal',fill='teal_light'):
    rect(x,y,w,22,fill,r=5);para(text,x+8,y+5,w-16,8.2,color,True,maxh=14)
def header(kicker,title,subtitle,page,sources):
    C.setFillColor(col('paper'));C.rect(0,0,W,H,stroke=0,fill=1)
    label('RICL / HUMAN-GEN SYSTEMS',M,25,8.2,'navy',True)
    right(tx('PROJECT RECORD  /  20 NOV 2026','项目阶段记录  /  2026.11.20'),W-M,25,8)
    line(M,46,W-M,46)
    label(kicker,M,64,9,'teal',True)
    h=para(title,M,85,CW,27 if LANG=='en' else 26,'navy',True,leading=31,maxh=66)
    para(subtitle,M,85+h+11,CW,10.4,'muted',maxh=45)
    footer(page,sources)
def footer(page,sources):
    line(M,793,W-M,793)
    label(tx('IMPLEMENTATION RECORD · ','实现阶段记录 · ')+sources,M,806,7.7)
    right(f'{page:02d} / 11',W-M,805,8,'navy',True)
def caption(text,x,y,w=CW):para(text,x,y,w,8.4,'muted',maxh=42)
def section(title,y):label(title,M,y,12,'navy',True)
def band(title,body,y,h=80,color='teal',fill='teal_light'):
    rect(M,y,CW,h,fill,r=9);para(title,M+16,y+13,CW-32,12,color,True)
    para(body,M+16,y+36,CW-32,10.3,'ink',maxh=h-43)

# All reference identifiers are stable across both language editions.
SRC=[
('S01','Task contracts and six stage skills','lessons/video-gen-transfer-hg.md'),
('S02','Generation, review and repair workflow','Agents/HumanGen_Agent/linux_current/runtime/workflow_codex123.md'),
('S03','Evidence-grounded planning and preflight','Agents/HumanGen_Agent/linux_current/runtime/prepare_generation_mac.py'),
('S04','Task-scoped policy invalidation','Agents/HumanGen_Agent/linux_current/runtime/pipeline_scheduling.py'),
('S05','Direct review and frozen proof validation','Agents/HumanGen_Agent/linux_current/runtime/direct_review.py'),
('S06','Sample-scoped immutable feedback','Agents/HumanGen_Agent/linux_current/runtime/pipeline_feedback.py'),
('S07','Watchdog and bounded diagnostic dispatch','Agents/HumanGen_Agent/linux_current/runtime/supervise_mac.py'),
('S08','Incident scope and repair discipline','Agents/HumanGen_Agent/linux_current/runtime/supervisor_prompt.md'),
('S09','Quota backoff and a single recovery probe','Agents/HumanGen_Agent/linux_current/runtime/codex_capacity.py'),
('S10','Content-keyed deterministic decode cache','Agents/HumanGen_Agent/linux_current/runtime/media_tools.py'),
('S11','Read-only content dashboard contract','Agents/HumanGen_Agent/linux_current/monitoring/website/README.md'),
('S12','GPU sampling and service-device mapping','Agents/HumanGen_Agent/linux_current/runtime/gpu_telemetry.py'),
('S13','Resource state and freshness classification','Agents/HumanGen_Agent/linux_current/runtime/gpu_monitor.py'),
('S14','Bounded advance planning buffer','Agents/HumanGen_Agent/linux_current/runtime/planning_capacity.py'),
('S15','Saved production configuration','Agents/HumanGen_Agent/linux_current/runtime/pipeline_config.json'),
('S16','Concrete fixed-base rejection event','Agents/HumanGen_Agent/linux_current/runtime/pipeline_feedback/events/press_stapler_016_transfer02/9c26e453e8195852ab491adff6bd6595df7ef3d0da489715a97ce980774b49a7.json'),
('S17','Media restoration and disabled Mac mirror','outputs/mac_media_cleanup_20261116/README.md'),
('S18','Per-task denominators and state model','Agents/HumanGen_Agent/linux_current/monitoring/website/pipeline_state.py'),
]

def cover():
    C.setFillColor(col('navy'));C.rect(0,0,W,H,fill=1,stroke=0)
    label('ROBOT-AI-LAB   /   RICL PROJECT',M,39,9,'white',True)
    label(tx('SYSTEMS ENGINEERING · STAGE RECORD','系统工程 · 阶段记录'),M,83,10,'8BD0C7',True)
    title=tx('Agentic Data\nGeneration System','智能体驱动的\n数据生成系统')
    para(title,M,119,CW,38 if LANG=='en' else 36,'white',True,leading=45,maxh=145)
    para(tx('A closed-loop production system for synthetic human manipulation video and atomic action clips.',
       '面向机器人学习的合成人类操作视频与原子动作片段闭环生产系统。'),M,274,CW-12,15,'D5E6E9',leading=22,maxh=70)
    # Cover miniature: visual identity of the full system, not an architectural count.
    rect(M,391,CW,208,'203D53',r=14)
    label(tx('EVIDENCE IN. VERIFIED ARTIFACTS OUT.','以任务证据为起点，以经审核的产物为交付。'),M+19,411,10,'white',True)
    xs=[M+20,M+183,M+346]
    vals=[(tx('Understand','理解任务'),tx('Task + demo evidence','任务与示范证据')),
          (tx('Generate & review','生成与审核'),tx('Plan / inspect / repair','规划 / 实审 / 修复')),
          (tx('Curate','整理交付'),tx('Clips + provenance','片段与溯源记录'))]
    for x,(t,b) in zip(xs,vals):
        rect(x,452,144,74,'paper',r=8);para(t,x+13,466,120,11,'teal',True);para(b,x+13,492,120,9,'ink')
    for x in xs[:-1]:arrow([(x+144,489),(x+158,489)],'8BD0C7')
    arrow([(M+418,531),(M+418,551),(M+254,551),(M+254,531)],'D3AD72',dash=[3,3])
    label(tx('Evidence-driven feedback','证据驱动的失败回流'),M+174,568,9,'D9BD93')
    para(tx('Specialist agents + a persistent, evidence-bound execution harness',
       '专用智能体 + 持久化、证据绑定的执行 harness'),M,633,CW,15,'white',True,maxh=50)
    para(tx('Generation orchestration · token-aware execution · content supervision · GPU observability',
       '生成编排 · token 开销控制 · 内容质量监督 · GPU 可观测性'),M,698,CW,11,'C3D6DD',maxh=42)
    line(M,772,W-M,772,'536B82')
    label(tx('ENGLISH EDITION  /  20 NOVEMBER 2026','中文版本  /  2026 年 11 月 20 日'),M,789,8.5,'D5E6E9')
    right('01 / 11',W-M,789,8.5,'white',True)

def framing():
    header('01 / POSITIONING',tx('What this project builds','这个项目构建了什么'),
       tx('A constrained production workflow with model-driven decisions inside each specialist stage.',
          '以受约束的生产流程为骨架，在专用阶段内引入基于证据的模型决策。'),2,'S01-S03, S07, S11-S15')
    band(tx('Project definition','项目定义'),tx('An agentic data generation system that translates task and robot-demo evidence into reviewed HumanGen / transfer-HG video, atomic clips, and traceable dataset records.',
       '把任务条件与机器人示范证据转化为经审核的 HumanGen / transfer-HG 视频、原子动作片段及可追溯数据集记录的智能体系统。'),180,99)
    section(tx('Three complementary layers','三个互补层次'),302)
    rows=[('Agent',tx('Perceive, plan, inspect and diagnose','感知、规划、实审与诊断'),tx('Sample-specific motion plans, visual judgments and repair recommendations.','针对样本制定动作计划、判断实际画面并选择修复策略。')),
          ('Harness',tx('Constrain, persist and coordinate','约束、持久化与协调'),tx('Stage skills, queues, ownership, retries, checkpoints and proof-bound publication.','阶段 skills、队列、负责人、重试、检查点及证据绑定入库。')),
          ('System',tx('Deliver and supervise the whole lifecycle','交付并监督完整生命周期'),tx('Generation services, curated artifacts, web supervision and GPU telemetry.','生成服务、数据产物、网站监督与 GPU 遥测。'))]
    for i,(t,a,b) in enumerate(rows):
        y=330+i*92;rect(M,y,CW,82,'white','line');label(t,M+15,y+15,14,'teal',True)
        para(a,M+112,y+13,CW-128,12,'navy',True);para(b,M+112,y+37,CW-128,10.2,maxh=38)
    section(tx('Engineering contributions captured here','本阶段记录的工程贡献'),631)
    para(tx('1. Ground generation in action mechanics and task completion conditions.\n2. Connect independent review to targeted repair and replanning.\n3. Preserve evidence and execution identity across hosts and retries.\n4. Expose content quality, workflow bottlenecks and GPU turnover in one web surface.',
       '1. 以动作机制与任务完成条件约束生成。\n2. 将独立审核连接到定向修复与重规划。\n3. 跨主机、跨重试保存证据与执行身份。\n4. 在网站中统一呈现内容质量、流程卡点和 GPU 周转。'),M,658,CW,11.1,maxh=106)
    caption(tx('HG = HumanGen human-operation video. Transfer-HG changes object instances while preserving the task contract. FULL denotes a rendered video before atomic clip export.',
       'HG 指 HumanGen 人类操作视频；transfer-HG 在保持任务契约的前提下替换物体实例。FULL 指原子切片导出前的生成视频。'),M,754)

def architecture(y=0):
    x=M;w=CW
    rect(x,y,w,78,'blue',r=10)
    label(tx('01  TASK & SOURCE EVIDENCE','01  任务与来源证据'),x+14,y+12,10,'navy',True)
    texts=[tx('Instruction + eval','指令与 eval'),tx('Robot demonstrations','机器人示范'),tx('Raw HG + approved frames','原版 HG 与已审条件帧')]
    bw=(w-44)/3
    for i,t in enumerate(texts):pill(t,x+12+i*(bw+10),y+38,bw,'navy','white')
    arrow([(x+w/2,y+78),(x+w/2,y+99)])
    rect(x,y+100,w,231,'white','line',10)
    label(tx('02  SPECIALIST AGENT WORK','02  专用智能体工作'),x+14,y+113,10,'teal',True)
    gap=13; nw=(w-52)/3;nx=[x+13,x+26+nw,x+39+2*nw]
    nodes=[(tx('Keyframe preparation','条件帧准备'),tx('Generate / repair\nIndependent pair review','生成 / 修复\n独立图对审核')),
           (tx('FULL production','FULL 视频生产'),tx('Plan + request preflight\nH3 render + FULL review','规划与请求预审\nH3 生成与 FULL 实审')),
           (tx('Atomic clip curation','原子片段整理'),tx('Choose native boundaries\nExport + independent review','选择原生帧边界\n导出与独立审片'))]
    for i,(a,b) in enumerate(nodes):node(nx[i],y+144,nw,111,a,b,'teal_light',fs=11)
    for i in (0,1):arrow([(nx[i]+nw,y+199),(nx[i+1]-2,y+199)])
    arrow([(nx[2]+nw/2,y+258),(nx[2]+nw/2,y+280),(nx[0]+nw/2,y+280),(nx[0]+nw/2,y+258)],'rust',dash=[3,3])
    para(tx('Rejected media returns with native-frame evidence; the diagnosed cause determines the repair stage.',
       '退回媒体携带原生帧证据；按诊断原因回到对应修复阶段。'),x+18,y+294,w-36,9.1,'rust',maxh=30)
    # Dashed control arrow points from the shared runtime into specialist work.
    arrow([(x+w/2,y+350),(x+w/2,y+333)],'slate',dash=[2,2])
    rect(x,y+351,w,80,'navy',r=9)
    label(tx('03  PERSISTENT EXECUTION HARNESS','03  持久化执行 HARNESS'),x+14,y+363,10,'white',True)
    para(tx('Scoped skills + context  |  asynchronous queues + bounded workers\nCheckpoint recovery  |  holds + retry policy  |  locks + SHA / CAS checks',
       '阶段 skills 与上下文  |  异步队列与有界工作池\n检查点恢复  |  暂停与重试策略  |  锁与 SHA / CAS 校验'),x+14,y+387,w-28,9.8,'D5E6E9',maxh=37)
    for xx in (x+123,x+w-123):arrow([(xx,y+431),(xx,y+451)])
    node(x,y+452,(w-14)/2,87,tx('04  Curated artifact store','04  数据产物与溯源'),tx('Frames / FULL / clips / manifest\nFrozen review evidence + lineage','条件帧 / FULL / clips / 清单\n冻结审核证据与来源链'),'white',fs=10.5)
    node(x+(w+14)/2,y+452,(w-14)/2,87,tx('05  Operations website','05  运行监督网站'),tx('Content, progress and incidents\nGPU, lanes, jobs and freshness','内容、进度与异常\nGPU、通道、作业与时效'),'white',fs=10.5)

def arch_page():
    header('02 / SYSTEM ARCHITECTURE',tx('One system, five modules','一套系统，五个模块'),
       tx('Conceptual grouping of implemented components; arrows show the artifact and feedback flow.',
          '按已实现组件归纳模块；箭头展示产物流转和失败反馈关系。'),3,'S01-S07, S11-S15')
    architecture(184)
    caption(tx('Solid teal: artifact flow. Dashed rust: repair feedback. Dashed blue: runtime control. The harness is a shared execution layer; H3 is the video backend.',
       '青绿实线：产物流转。砖红虚线：修复反馈。灰蓝虚线：运行控制。Harness 是共享执行层；H3 是视频生成后端。'),M,740)

def workflow():
    header('03 / GENERATION & QUALITY',tx('Generation closes the loop','生成、审核与修复形成闭环'),
       tx('Each approval advances one stage. Each rejection preserves its evidence and targets a specific cause.',
          '每次通过只推进对应阶段；每次退回保留证据，并针对明确原因修复。'),4,'S01-S03, S05-S06, S15')
    ys=[180,265,350,435]; xx=M+111; ww=289
    vals=[(tx('Approved conditioning frames','已独立通过的条件帧'),tx('Task goal, hands, objects and support','任务目标、手别、物体与支撑')),
          (tx('Plan + independent request preflight','规划与独立请求预审'),tx('Freeze the exact request before H3','在提交 H3 前冻结实际请求')),
          (tx('H3 render + independent FULL review','H3 生成与独立 FULL 实审'),tx('Inspect the actual MP4 and native frames','检查实际 MP4 与原生帧')),
          (tx('Export clips + independent clip review','片段导出与独立审片'),tx('Verify each clip and the complete chain','逐段核对并检查完整动作链'))]
    for y,(t,b) in zip(ys,vals):node(xx,y,ww,65,t,b,'white',fs=10.8)
    for y in ys[:-1]:arrow([(xx+ww/2,y+65),(xx+ww/2,y+83)])
    # Rework loops outside the primary flow.
    arrow([(xx,382),(M+18,382),(M+18,212),(xx-2,212)],'rust',dash=[4,3])
    para(tx('Input conflict:\nrepair frames\nand re-review','条件图冲突：\n修图并重审'),M+28,283,76,9.2,'rust',maxh=65)
    arrow([(xx+ww,382),(W-M-11,382),(W-M-11,297),(xx+ww+2,297)],'amber',dash=[4,3])
    para(tx('Motion failure:\nreplan request','动作失败：\n重规划请求'),W-M-98,319,82,8.8,'amber',maxh=40)
    section(tx('Five retained FULL review dimensions','FULL 实审保留的五个维度'),526)
    checks=[tx('Action + goal','动作与目标'),tx('Working hands','工作手'),tx('Identity + fixed props','身份与固定物'),tx('Continuity + contact','连续性与接触'),tx('Reference alignment','参考对齐')]
    for i,t in enumerate(checks):
        y=555+i*27;dot(M+5,y+6);label(t,M+19,y,10.5,'ink')
    band(tx('Long actions are independently rendered segments','长动作按独立小段生产'),tx('Selected tasks use two or three FULL renders joined at approved shared frames. Each segment needs its own planning and review; the parent chain also needs real transition checks.',
       '指定任务使用两个或三个独立 FULL，并以已审共享帧衔接。每段分别规划和审核，父链另核真实原生衔接。'),702,77)

def efficiency_diagram(y):
    widths=[155,178,150];xs=[M,M+167,M+357]
    vals=[(tx('Deterministic work','确定性工作'),tx('Hashes, JSON, queues,\ntelemetry and timestamps','哈希、JSON、队列、\n遥测与时间戳'),'blue','navy'),
          (tx('Scoped evidence packet','限定范围的证据包'),tx('Stage skill + current sample\nApplicable feedback + frames','当前阶段 skill 与样本\n适用反馈与画面'),'teal_light','teal'),
          (tx('Model judgment','模型判断'),tx('Mechanics, visual review,\nrepair and motion planning','动作机制、视觉实审、\n修复与动作规划'),'white','teal')]
    for x,w,(t,b,f,a) in zip(xs,widths,vals):node(x,y,w,93,t,b,f,a,10.4)
    for i in (0,1):arrow([(xs[i]+widths[i],y+47),(xs[i+1]-2,y+47)])

def efficiency():
    header('04 / TOKEN-AWARE EXECUTION',tx('Spend model effort selectively','把模型开销用在需要判断的地方'),
       tx('Implemented mechanisms for reducing repeated calls and irrelevant context. Benefits are not yet a measured token-saving rate.',
          '已实现的重复调用与无关上下文控制机制；收益尚未换算成实测 token 节省率。'),5,'S01, S03-S10')
    efficiency_diagram(183)
    # Four-column content is deliberately avoided: two columns remain readable in both languages.
    items=[
      (tx('01  Route skills by stage','01  按阶段加载 skills'),tx('Load generation, frame review, FULL review, export or clip review instructions only when that stage is assigned.','仅在执行对应阶段时加载生成、审图、FULL 实审、切片或审片规则。'),tx('Less unrelated instruction context','减少无关指令上下文')),
      (tx('02  Scope feedback and invalidation','02  限定反馈与失效范围'),tx('Use sample feedback and task-specific policy signatures. An unrelated task update does not invalidate a valid plan.','按样本读取反馈，按任务计算策略签名；其他任务更新不使有效计划失效。'),tx('Avoid unnecessary replanning calls','避免无关重规划调用')),
      (tx('03  Keep verification in code','03  用程序完成确定性校验'),tx('Validate file hashes, request bindings, JSON and publication conditions without a visual-model call.','由代码校验文件 SHA、请求绑定、JSON 和入库条件，无需视觉模型判断。'),tx('Reserve model calls for semantic work','模型调用集中于语义工作')),
      (tx('04  Remove a redundant review tier','04  移除额外初审层'),tx('The saved direct-review policy disables Qwen screening and routes each produced FULL to independent Codex review.','保存的直接审核策略关闭 Qwen 初审，FULL 出片后直接进入独立 Codex 实审。'),tx('Fewer inference stages; hard checks retained','减少推理层次，保留硬验收')),
      (tx('05  Reuse verified work','05  复用已核实工作'),tx('Resume the same job / MP4 on technical failure; reuse an approval only while its file and applicable contract remain valid.','技术失败沿用原 job / MP4；仅在文件与适用契约仍有效时复用通过记录。'),tx('Avoid repeated generation and review','减少重复生成与审核')),
      (tx('06  Bound diagnosis and quota retries','06  限定诊断与额度重试'),tx('Assign one managed incident, retain checkpoints and use shared backoff with one recovery probe after quota exhaustion.','单轮领取一项异常，保留检查点；额度耗尽后统一退避，并只放行一个恢复探针。'),tx('Limit repeated exploration and failed calls','控制重复探索与失败调用')),
    ]
    for i,(t,b,e) in enumerate(items):
        yy=296+(i//2)*132;xx=M+(i%2)*(CW+14)/2;ww=(CW-14)/2
        rect(xx,yy,ww,121,'white','line');para(t,xx+12,yy+12,ww-24,10.6,'teal',True,maxh=30)
        para(b,xx+12,yy+40,ww-24,9.5,maxh=55)
        para(e,xx+12,yy+99,ww-24,8.1,'muted',maxh=15)
    rect(M,705,CW,73,'amber_light',r=8)
    para(tx('Additional compute / I/O optimization','额外的计算与 I/O 优化'),M+13,717,CW-26,11,'amber',True)
    para(tx('A content-keyed decoder cache reuses successful deterministic results (64 MiB / 128 entries). This saves decoding, not automatically LLM tokens. Watchdog observation is scripted; bounded model diagnosis can still recur.',
       '按内容 SHA 缓存成功解码结果（64 MiB / 128 项），收益属于解码计算，不能直接算成 LLM token。巡检由脚本执行，但有界模型诊断仍可能周期发生。'),M+13,740,CW-26,9.2,maxh=32)

def provenance_diagram(y):
    labels=[tx('Input identity','输入身份'),tx('Exact request','实际请求'),tx('Actual media','实际媒体'),tx('Frozen review','冻结审核'),tx('Registered output','登记产物')]
    sub=[tx('source + frame SHA','来源与条件帧 SHA'),tx('prompt + request SHA','提示词与请求 SHA'),tx('job + MP4 SHA','job 与 MP4 SHA'),tx('rules + evidence SHA','规则与证据 SHA'),tx('manifest + receipt','清单与回执')]
    bw=(CW-40)/5
    for i,(a,b) in enumerate(zip(labels,sub)):
        x=M+i*(bw+10);rect(x,y,bw,86,'white','line');para(a,x+9,y+12,bw-18,9.9,'teal',True,maxh=30);para(b,x+9,y+46,bw-18,8.0,maxh=29)
        if i<4:arrow([(x+bw,y+43),(x+bw+8,y+43)])

def reliability():
    header('05 / EXECUTION & PROVENANCE',tx('A verdict belongs to exact bytes','审核结论绑定到具体文件'),
       tx('Persistent identity makes recovery possible without silently changing what was generated or reviewed.',
          '持久化身份支持恢复执行，并明确保存生成和审核时所依据的版本。'),6,'S01, S05-S10, S17-S18')
    provenance_diagram(185)
    caption(tx('Each link binds the relevant request, media, review rules and evidence. A path or a status flag alone is insufficient.',
       '链路逐项绑定实际请求、媒体、审核规则和证据；单靠路径或状态标记不足以证明通过。'),M,283)
    cards=[(tx('Ownership and bounded concurrency','负责人和有界并发'),tx('Incident owners, deadlines and source-level repair ownership prevent duplicate work. Independent pools let other samples continue.','异常有负责人和期限；同一来源限定修图 owner，避免重复执行。独立工作池允许其他样本继续。')),
           (tx('Recovery preserves submitted identity','恢复时保留提交身份'),tx('Reuse recorded job IDs and requests. Technical failures are not visual failures and do not spend media-quality retry counts.','恢复沿用已记录的 job ID 和请求；技术失败与视觉失败分开，不消耗媒体质量重试次数。')),
           (tx('Publication validates current state','入库核对当前状态'),tx('Locks and compare-and-swap checks guard registration. Frozen historical evidence remains attached to its own input revision.','登记使用锁和比较后更新（CAS）校验；冻结的历史证据保留其原输入版本绑定。'))]
    for i,(a,b) in enumerate(cards):
        y=332+i*105;node(M,y,CW,93,a,b,'white',fs=12)
    section(tx('Three distinct acceptance boundaries','三个独立的验收边界'),667)
    for i,(a,b) in enumerate([(tx('Frames','条件帧'),tx('Static consistency','静态一致性')),(tx('FULL','完整视频'),tx('Actual action process','实际动作过程')),(tx('Clips','原子片段'),tx('Export + chain continuity','导出文件与链路连续性'))]):
        x=M+i*(CW+12)/3;w=(CW-24)/3;rect(x,697,w,62,'teal_light');label(a,x+12,709,11,'teal',True);para(b,x+12,733,w-24,8.8,maxh=18)
    caption(tx('Clip exports record [start_frame, end_frame). An approved salvage clip never converts its rejected source FULL into a pass.',
       '切片边界使用 [start_frame, end_frame)。独立挽救片段通过，不会把已退回的源 FULL 改成通过。'),M,765)

def content_diagram(y):
    rect(M,y,CW,90,'navy',r=9)
    label(tx('READ-ONLY OPERATIONS WEBSITE','只读运行监督网站'),M+15,y+13,10,'white',True)
    para(tx('Production snapshots + exception ledger + queue + exact media / review bindings',
       '生产快照 + 异常账本 + 当前队列 + 实际媒体与审核绑定'),M+15,y+39,CW-30,10,'D5E6E9',maxh=35)
    arrow([(M+CW/2,y+90),(M+CW/2,y+109)])
    # A schematic view of the actual dashboard modules; no invented live counts.
    rect(M,y+110,CW,244,'white','line')
    label(tx('SCHEMATIC VIEW · no live production counts','界面模块示意 · 不展示实时生产数量'),M+14,y+123,8.3,'muted',True)
    stages=[tx('Frames: create','Frame 生成'),tx('Frames: review','Frame 审核'),tx('FULL: create','FULL 生成'),tx('FULL: review','FULL 审核'),tx('Clips: export','Clip 生成'),tx('Clips: review','Clip 审核'),tx('FULL → frame repair','FULL → Frame 返修')]
    for i,t in enumerate(stages):
        if i<4:x=M+13+i*(CW-26+8)/4;yy=y+148;ww=(CW-50)/4
        else:x=M+13+(i-4)*(CW-26+8)/3;yy=y+181;ww=(CW-42)/3
        pill(t,x,yy,ww)
    node(M+13,y+218,215,117,tx('Sample evidence detail','样本证据详情'),tx('Current / historical image versions\nNative-size evidence and SHA\nFailure reasons and review basis','当前 / 历史图像版本\n原生尺寸证据与 SHA\n失败原因与审核依据'),'paper',fs=10.4)
    node(M+241,y+218,CW-254,117,tx('Progress and exceptions','进度与异常'),tx('FULL / complete chain / clips\nOwner, deadline and next action\nStale snapshot and missing workers','FULL / 完整链 / 独立片段\n负责人、期限与下一步\n快照过期与缺失工作者'),'paper',fs=10.4)

def web_content():
    header('06 / WEB CONTENT SUPERVISION',tx('Make quality and blockers visible','让内容质量与生产卡点可见'),
       tx('The website is a read-only evidence surface for human supervision. Review records remain authoritative.',
          '网站作为人工监督的只读证据界面；审核结论以实际记录和媒体绑定为准。'),7,'S11, S17-S18')
    content_diagram(178)
    section(tx('Operational semantics that matter','监督界面的关键语义'),555)
    items=[(tx('Version-aware inspection','按版本查看'),tx('Current inputs and historical reviewed candidates stay separate; missing or mismatched SHA is shown explicitly.','当前输入与历史受审候选分开；缺失文件和 SHA 不匹配显式标注。')),
           (tx('Honest stage accounting','按阶段诚实计数'),tx('Frames, FULLs, complete chains and independent clips use their own units. Repair overlaps other stages and is not additive.','条件帧、FULL、完整链和独立片段各用自己的单位；返修与其他阶段重叠，不能相加。')),
           (tx('Actionable attention','区分处理责任'),tx('Automatic recovery, user pause, backend diagnosis and verified human-only dependencies have distinct labels.','自动处理、用户暂停、后台排查和已核实的人工依赖分别标示。'))]
    yy=582
    for a,b in items:
        para(a,M,yy-1,143,10.7,'teal',True,maxh=34);para(b,M+156,yy-1,CW-156,9.7,maxh=42);yy+=62
    caption(tx('Documented cadence: content export every minute; page refresh every 15 s. The Mac image mirror is intentionally disabled; the Linux website is the viewing surface.',
       '记录中的刷新机制：内容每分钟导出，页面每 15 秒刷新。Mac 图片镜像按清理决定停用，查看 Linux 网站。'),M,762)

def gpu_diagram(y):
    # Resource identity chain.
    labels=[tx('Slurm allocation','Slurm 分配'),tx('Node + service','节点与服务'),tx('Physical GPU','物理 GPU'),tx('Lane + sample','通道与样本')]
    bodies=[tx('Current-user jobs\nRUNNING / PENDING','当前用户作业\n运行 / 排队'),tx('Port + owned PID\nCUDA device selector','端口与自有 PID\nCUDA 设备选择器'),tx('UUID + utilization\nMemory + sample time','UUID 与利用率\n显存与采样时间'),tx('Health + client state\nAsset / attempt','健康与客户端状态\n样本 / attempt')]
    nw=(CW-36)/4
    for i,(a,b) in enumerate(zip(labels,bodies)):
        x=M+i*(nw+12);node(x,y,nw,113,a,b,'white',fs=9.7)
        if i<3:arrow([(x+nw,y+55),(x+nw+10,y+55)])
    rect(M,y+137,CW,83,'teal_light');label(tx('CROSS-CHECK, THEN CLASSIFY','交叉核验后再分类'),M+14,y+150,10,'teal',True)
    para(tx('Working / waiting / finishing / stalled / paused / switching / offline / unknown',
       '计算中 / 等待 / 收尾 / 停滞 / 暂停 / 切换 / 离线 / 未核实'),M+14,y+177,CW-28,10.2,maxh=30)
    arrow([(M+CW/2,y+220),(M+CW/2,y+241)])
    node(M,y+242,CW,75,tx('Web resource panel + advance request buffer','网站资源面板与提前请求缓冲'),tx('Observe real GPU activity; distinguish upstream request starvation from delivery or service problems.','观察真实 GPU 活动，区分上游请求不足、投递停滞与服务问题。'),'white',fs=11)

def web_gpu():
    header('07 / GPU OBSERVABILITY',tx('Observe GPU activity and turnover','监督计算活动与 GPU 周转'),
       tx('Resource identity, service health and utilization are joined to actual generation work.',
          '把资源身份、服务健康与实际利用率连接到具体生成工作。'),8,'S12-S15')
    gpu_diagram(178)
    # Three precise timing cards, recorded configuration not live health claims.
    vals=[('10 s',tx('node sampling','节点采样')),('15 s',tx('resource sync / page','资源同步 / 页面刷新')),('60 s',tx('GPU evidence freshness','GPU 证据有效时限'))]
    for i,(a,b) in enumerate(vals):
        x=M+i*(CW+12)/3;w=(CW-24)/3;rect(x,518,w,66,'blue');label(a,x+13,530,20,'navy',True);para(b,x+13,558,w-26,8.6,maxh=18)
    section(tx('Keep approved requests ahead of render lanes','让已审请求提前于生成通道准备好'),607)
    para(tx('Ready target = max(16, 4 × active lanes). The saved configuration allows 12 concurrent planning slots (implementation cap: 16), 3 FULL reviewers and 2 input-repair workers. These are configuration values, not measured throughput.',
       '已审请求目标库存 = max(16, 4 × 活跃通道数)。保存配置为 12 个并发规划槽（实现上限 16）、3 个 FULL 审核槽和 2 个修图槽。这些是配置值，不是实测吞吐。'),M,632,CW,10.6,maxh=77)
    rect(M,711,CW,68,'amber_light')
    para(tx('Heuristics remain visible','明确保留启发式判断边界'),M+13,722,CW-26,11,'amber',True)
    para(tx('Utilization ≥ 5% is a working heuristic. Request waits of 120 s can be flagged; sustained low-utilization renders need at least 180 s. Stale GPU evidence becomes unknown; allocated memory alone is not proof of computation.',
       '利用率 ≥ 5% 作为计算启发式。等待请求 120 秒可标停滞；生成中持续低利用率至少观察 180 秒。GPU 证据过期标为未核实；显存占用本身不证明正在计算。'),M+13,744,CW-26,9.1,maxh=32)

def case_study():
    header('08 / EVIDENCE-BOUND FAILURE CASE',tx('From a failed frame range to repair','从失败帧段到定向修复'),
       tx('A real saved rejection illustrates the feedback contract. It does not establish a later successful repair.',
          '用一条真实退回记录展示反馈契约；此记录不证明后续修复已成功。'),9,'S03, S05-S06, S16')
    rect(M,179,CW,68,'navy');label('press_stapler_016_transfer02',M+15,194,13,'white',True)
    label(tx('Attempt 04  /  contract revision 03  /  reject','Attempt 04  /  契约修订 03  /  退回'),M+15,222,9.5,'D5E6E9')
    # Native-frame timeline derived from recorded observation, not media imagery.
    label(tx('RECORDED NATIVE-FRAME OBSERVATION','已记录的原生帧观察'),M,273,9,'teal',True)
    xx=M+20;ww=CW-40;yy=322
    line(xx,yy,xx+ww,yy,'line',3)
    def fx(f):return xx+ww*f/123
    line(fx(48),yy,fx(56),yy,'rust',9)
    line(fx(56),yy,fx(123),yy,'amber',3,dash=[3,2])
    for f in (0,48,56,123):dot(fx(f),yy,'rust' if f in (48,56) else 'navy');label(str(f),fx(f)-5,yy+17,9)
    para(tx('Base shifts during frames 48-56','第 48-56 帧底座发生位移'),M,367,CW,12,'rust',True)
    para(tx('The review records the base footprint and hinge mount moving toward the near table edge, with the displacement remaining through frame 123. Stable scene references support a fixed-base failure rather than camera motion.',
       '审核记录指出：底座轮廓和铰链安装点朝桌面近侧边缘移动，位移持续至第 123 帧。场景参照保持稳定，因此判为固定底座条件失败。'),M,396,CW,11,maxh=75)
    steps=[(tx('1  Preserve the failure identity','1  保存失败身份'),tx('Bind source video, input frames, review revision and exact evidence SHA.','绑定源视频、条件帧、审核修订和实际证据 SHA。')),
           (tx('2  Convert observation to correction','2  将观察转成修复要求'),tx('Keep base, feet, rear mount and hinge fixed throughout reach and loaded press.','要求伸手与受力按压全程保持底座、支脚、后安装座和铰链固定。')),
           (tx('3  Repair the diagnosed dependency','3  修复已诊断的依赖'),tx('Resolve contradictory endpoints, independently review the whole input pair and affected raw source, then preflight a changed request.','修复冲突端点，独立审核整对输入及受影响原版来源，再预审变更后的请求。'))]
    for i,(a,b) in enumerate(steps):node(M,486+i*88,CW,76,a,b,'white',fs=11)
    caption(tx('Evidence identity: video SHA prefix 3985cecb2fa4… ; event SHA prefix 9c26e453e819… . Timeline summarizes the stored review; the underlying MP4 was not re-reviewed for this report.',
       '证据身份：视频 SHA 前缀 3985cecb2fa4…；事件 SHA 前缀 9c26e453e819…。时间线概括已保存审核，本报告未重新实审该 MP4。'),M,760)

def contributions():
    header('09 / PROJECT SHOWCASE',tx('The contribution is the system','项目展示应突出系统贡献'),
       tx('A reusable project description, together with a clear boundary between implemented capability and measured benefit.',
          '给出可复用的项目介绍，并清楚区分已实现能力与已测量收益。'),10,'S01-S15, S18')
    band(tx('Portfolio statement','项目介绍'),tx('Designed and implemented a closed-loop agentic pipeline for synthetic manipulation video, combining demonstration-grounded planning, independent multimodal review and failure-driven repair with persistent orchestration, provenance tracking and web-based content / GPU supervision.',
       '设计并实现面向机器人操作学习的闭环合成视频数据系统，结合示范驱动规划、独立多模态审核与失败驱动修复，构建持久化编排、数据溯源及基于网站的内容与 GPU 监督机制。'),178,123)
    section(tx('Implemented capabilities documented in this record','本记录覆盖的已实现能力'),326)
    pairs=[(tx('Task-aware generation','任务感知生成'),tx('Translate mechanics, hands, contact and goal conditions into sample-specific plans.','将机制、手别、接触和完成条件转成样本级计划。')),
           (tx('Closed-loop quality control','闭环质量控制'),tx('Independent stage reviews feed scoped repair and replanning.','阶段独立审核反馈到限定范围的修复与重规划。')),
           (tx('Persistent production harness','持久化生产 harness'),tx('Coordinate queues, ownership, recovery and exact evidence bindings.','协调队列、负责人、恢复与精确证据绑定。')),
           (tx('Observable operations','可观测运行'),tx('Expose content versions, exceptions, GPU activity and request-buffer shortages.','展示内容版本、异常、GPU 活动和请求缓冲不足。'))]
    for i,(a,b) in enumerate(pairs):
        yy=354+i*53;para(a,M,yy-1,142,10.5,'teal',True,maxh=32);para(b,M+156,yy-1,CW-156,9.7,maxh=36)
    section(tx('Quantify next using the same acceptance contract','下一阶段按同一验收契约量化'),587)
    metrics=[(tx('Token efficiency','Token 效率'),tx('Input / output / cached tokens and calls per accepted artifact.','每个合格产物的输入 / 输出 / 缓存 token 与调用次数。')),
             (tx('Production efficiency','生产效率'),tx('GPU-seconds and wall time per accepted FULL and complete chain.','每个合格 FULL 与完整链的 GPU 秒和墙钟时间。')),
             (tx('Quality and intervention','质量与人工介入'),tx('First-pass rate, repair recovery rate and human interventions per 100 samples.','首轮通过率、修复恢复率及每百样本人工介入次数。'))]
    for i,(a,b) in enumerate(metrics):
        yy=614+i*42;label(a,M,yy,9.8,'navy',True);para(b,M+156,yy-1,CW-156,9.3,maxh=32)
    caption(tx('Use matched task mixes and review policies. Model-based visual review is a quality gate, not physical ground truth or calibrated RGB measurement. No token percentage, GPU speedup or downstream learning gain is claimed here.',
       '对照须保持任务构成与审核规则一致。模型视觉审核是质量门禁，不能替代物理真值或标定测量。本记录不宣称 token 节省比例、GPU 加速倍数或下游学习增益。'),M,755)

def references():
    header('10 / RECORD & EVIDENCE',tx('A bounded implementation snapshot','可追溯的阶段实现记录'),
       tx('Prepared 20 November 2026. Local implementation evidence inspected here spans the November 13-16 production revisions.',
          '编制于 2026 年 11 月 20 日。本次查阅的本地实现证据覆盖 11 月 13-16 日生产修订。'),11,'S01-S18')
    para(tx('This is an architecture and engineering record, not a live operational audit. A fresh Linux project read returned a mount error, so live completion counts and current service health are not asserted. Configuration snapshots are labeled as such.',
       '本文记录架构与工程实现，不作为实时运行审计。新一轮 Linux 项目读取返回挂载错误，因此不宣称当前完成数量或服务健康；配置均按保存快照标示。'),M,177,CW,10.4,maxh=66)
    section(tx('Source index','证据索引'),254)
    # Short portable locators in print; full paths, hashes and exact line spans are in the companion manifest.
    short=[
      ('S01','Lesson / six stage contracts','lessons/video-gen-transfer-hg.md'),
      ('S02','Production workflow','runtime/workflow_codex123.md'),
      ('S03','Planner + preflight','runtime/prepare_generation_mac.py'),
      ('S04','Scoped invalidation','runtime/pipeline_scheduling.py'),
      ('S05','Frozen proof checks','runtime/direct_review.py'),
      ('S06','Immutable feedback','runtime/pipeline_feedback.py'),
      ('S07','Watchdog dispatch','runtime/supervise_mac.py'),
      ('S08','Incident discipline','runtime/supervisor_prompt.md'),
      ('S09','Quota backoff','runtime/codex_capacity.py'),
      ('S10','Decode cache','runtime/media_tools.py'),
      ('S11','Dashboard contract','monitoring/website/README.md'),
      ('S12','GPU / service identity','runtime/gpu_telemetry.py'),
      ('S13','GPU state + freshness','runtime/gpu_monitor.py'),
      ('S14','Planning buffer','runtime/planning_capacity.py'),
      ('S15','Saved configuration','runtime/pipeline_config.json'),
      ('S16','Fixed-base failure event','pipeline_feedback/events/press_stapler_016_transfer02/'),
      ('S17','Media restoration record','outputs/mac_media_cleanup_20261116/README.md'),
      ('S18','Pipeline state semantics','monitoring/website/pipeline_state.py'),
    ]
    for i,(sid,a,b) in enumerate(short):
        yy=284+i*21.8
        label(sid,M,yy,8.5,'teal',True);label(a,M+34,yy,8.5,'navy')
        # long locator abbreviated in print, manifest preserves full identity
        para(b,M+190,yy-1,CW-190,7.4,'muted',maxh=19)
    rect(M,690,CW,85,'blue')
    para(tx('Companion files','随附可复用材料'),M+13,702,CW-26,11,'navy',True)
    para(tx('evidence_manifest.json stores complete project-relative source paths, SHA-256 hashes and captured line spans. build_report.py regenerates both editions. figures/ contains standalone vector PDFs and PNG previews. All figures are original architectural schematics; no illustrative dashboard value represents live telemetry.',
       'evidence_manifest.json 保存完整项目相对路径、SHA-256 与引用行范围；build_report.py 可重建两个版本。figures/ 提供独立矢量 PDF 和 PNG 预览。全部图形均为原创架构示意；界面示意不代表实时遥测。'),M+13,727,CW-26,9.0,maxh=42)

PAGES=[cover,framing,arch_page,workflow,efficiency,reliability,web_content,web_gpu,case_study,contributions,references]

def write_manifest():
    manifest_path=HERE/'evidence_manifest.json'
    if manifest_path.exists():
        old=json.loads(manifest_path.read_text())
        for item in old['sources']:
            original=ROOT/item['project_relative_path']
            if not original.exists() or hashlib.sha256(original.read_bytes()).hexdigest()!=item['sha256']:
                raise RuntimeError('Stage-record source changed; preserve this record and create a new dated revision: '+item['id'])
    lines={
      'S01':[(1,48),(114,143),(170,220)],'S02':[(1,31)],'S03':[(308,440),(457,551),(577,650)],
      'S04':[(1,11),(58,68),(86,125)],'S05':[(1,116)],'S06':[(1,186)],'S07':[(75,115),(129,176),(195,290)],
      'S08':[(1,12),(35,40),(55,74)],'S09':[(1,60),(118,166)],'S10':[(1,54)],'S11':[(1,105)],
      'S12':[(20,169)],'S13':[(1,130)],'S14':[(1,22)],'S15':[(1,125)],'S16':[(1,49)],'S17':[(1,31)],'S18':[(1,200)]}
    records=[]
    for sid,desc,rel in SRC:
        p=ROOT/rel;b=p.read_bytes();n=len(b.decode().splitlines())
        records.append(dict(id=sid,description=desc,project_relative_path=rel,sha256=hashlib.sha256(b).hexdigest(),
          bytes=len(b),lines=n,inspected_line_spans=[[a,min(z,n)] for a,z in lines[sid] if a<=n],
          file_modified_utc=datetime.fromtimestamp(p.stat().st_mtime,timezone.utc).isoformat()))
    data=dict(title='RICL Agentic Data Generation System',record_date='2026-11-20',
      evidence_basis='Local saved implementation revisions, November 13-16, 2026; no fresh production status claimed.',
      remote_read='Read-only SSH reached Linux; project runtime returned Transport endpoint is not connected.',
      measured_token_reduction=None,measured_gpu_speedup=None,production_totals_claimed=False,
      terminology=dict(agent='Evidence interpretation and task-specific model decisions.',harness='Persistent constrained orchestration, context, validation and recovery.'),
      sources=records)
    manifest_path.write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n')

def main():
    global C,LANG
    write_manifest()
    for LANG in ('en','zh'):
        name='RICL_Agentic_Data_Generation_System_'+('EN' if LANG=='en' else 'ZH')+'.pdf'
        C=canvas.Canvas(str(HERE/name),pagesize=(W,H),pageCompression=1)
        C.setTitle(tx('RICL Agentic Data Generation System | Project Record','RICL 智能体数据生成系统 | 项目阶段记录'))
        C.setAuthor('RICL Project / Robot-AI-Lab');C.setSubject('Architecture, token-aware execution, content supervision and GPU observability')
        C.setCreator('RICL project record / ReportLab vector publishing')
        for i,fn in enumerate(PAGES):
            C.bookmarkPage('page'+str(i+1));C.addOutlineEntry(tx(['Cover','Project positioning','System architecture','Generation loop','Token efficiency','Provenance','Content supervision','GPU supervision','Failure case','Project contribution','Evidence index'][i],['封面','项目定位','系统架构','生成闭环','Token 开销控制','证据溯源','内容监督','GPU 监督','失败案例','项目贡献','证据索引'][i]),'page'+str(i+1),0)
            fn();C.showPage()
        C.save()
        # Standalone diagrams use the same drawing commands as the report pages.
        for stem,fn,height in [('system_architecture',architecture,570),('token_efficiency',efficiency_diagram,128),('evidence_chain',provenance_diagram,120),('content_supervision',content_diagram,389),('gpu_supervision',gpu_diagram,350)]:
            C=canvas.Canvas(str(HERE/'figures'/f'{stem}_{LANG}.pdf'),pagesize=(W,height))
            C.setTitle(stem.replace('_',' ')+' / '+LANG)
            # Top coordinates are defined for A4; translate the origin so the crop begins at 0.
            C.translate(0,height-H);fn(15);C.showPage();C.save()
    (HERE/'layout_checks.json').write_text(json.dumps(OVERFLOWS,ensure_ascii=False,indent=2)+'\n')
    print(json.dumps({'reports':2,'pages_each':11,'standalone_figures':10,'layout_overflows':OVERFLOWS},ensure_ascii=False))

if __name__=='__main__':main()
