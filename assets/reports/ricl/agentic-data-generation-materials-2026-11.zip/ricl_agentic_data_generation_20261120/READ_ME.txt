RICL Agentic Data Generation System / Project stage record
Record date: 20 November 2026

DELIVERABLES
- RICL_Agentic_Data_Generation_System_EN.pdf: English edition, 11 pages.
- RICL_Agentic_Data_Generation_System_ZH.pdf: Chinese edition, 11 pages.
- figures/: five reusable module diagrams in both languages, as vector PDF and PNG.
- build_report.py: editable bilingual text, layout, palette and vector drawing source.
- evidence_manifest.json: 18 source identities, full project-relative paths, line spans and SHA-256.
- verification.json: page, text, geometry, source-integrity and visual-review checks.

SCOPE
This is an implementation-stage portfolio and engineering record. It documents the saved
November 13-16 implementation revisions inspected on November 20. It does not assert live
production counts, a measured token-saving percentage or downstream learning improvements.
GPU timing and worker counts are documented implementation/configuration values.
The case-study timeline summarizes a saved rejection, not a new visual review of the MP4.

REBUILD
Keep this directory at output/pdf/ricl_agentic_data_generation_20261120/ within RICL-Project.
Use Python with ReportLab on macOS (Arial and STHeiti fonts), then run:
  python3 output/pdf/ricl_agentic_data_generation_20261120/build_report.py
The builder refuses to refresh this dated record if an existing evidence source hash changes.
Create a new dated revision for later implementation changes. PNG figure previews are
rendered separately with Poppler; the script writes the reports and standalone vector PDFs.

DESIGN
A4 portrait; navy, teal and warm neutral palette; amber/rust for diagnostic and repair flow.
All diagrams are drawn as vector geometry. Text remains selectable, with embedded fonts.

中文说明
中英文各 11 页，按项目展示用途编排。figures/ 含五类模块图的中英文矢量 PDF 与 PNG。
build_report.py 可编辑正文和图形；证据索引保留 18 份来源的路径与 SHA。
本材料记录已查阅的阶段实现，不宣称实时生产状态、实测 token 节省比例或训练效果。
